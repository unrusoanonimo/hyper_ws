use sqlite::{Connection, Statement};

use crate::model;

use super::{Error, Result};

pub struct IpInfoModule<'a> {
    connection: Connection,
    stmts: Option<Statements<'a>>,
}
impl<'a> IpInfoModule<'a> {
    pub fn new() -> Self {
        let connection: sqlite::Connection = sqlite::open("data/ip_info.sqlite").unwrap();

        let module: IpInfoModule = Self {
            connection,
            stmts: None,
        };
        module.build();
        module
    }
    fn build(&'a self) {
        let uncheked = unsafe { (self as *const _ as *mut Self).as_mut().unwrap() };
        let st = Statements::new(&self.connection);
        uncheked.stmts = Some(st);
    }

    pub fn get_by_ip(&mut self, ip: &str) -> Result<model::IpInfo> {
        let statement = &mut self.stmts.as_mut().unwrap().get_by_ip;
        statement.reset()?;
        statement.bind((":ip", ip))?;

        statement.next().or(Err(Error::InvalidOperation))?;

        let ip: String = statement.read("ip")?;
        let city: String = statement.read("city")?;
        let region: String = statement.read("region")?;
        let country: String = statement.read("country")?;
        let loc: String = statement.read("loc")?;
        let org: Option<String> = statement.read("org")?;
        let postal: String = statement.read("postal")?;
        let timezone: String = statement.read("timezone")?;

        let info = model::IpInfo {
            data: model::ip_info::DataFromIp {
                city,
                country,
                ip,
                loc,
                postal,
                region,
                timezone,
                org,
            },
        };
        Ok(info)
    }

    pub fn insert(&mut self, info: &model::IpInfo) -> Result<()> {
        let statement = &mut self.stmts.as_mut().unwrap().insert;
        statement.reset()?;

        statement.bind((":ip", info.ip.as_str()))?;
        statement.bind((":city", info.city.as_str()))?;
        statement.bind((":region", info.region.as_str()))?;
        statement.bind((":country", info.country.as_str()))?;
        statement.bind((":loc", info.loc.as_str()))?;
        statement.bind((":org", info.org.as_ref().map(|v| v.as_str())))?;
        statement.bind((":postal", info.postal.as_str()))?;
        statement.bind((":timezone", info.timezone.as_str()))?;

        statement.next().or(Err(Error::InvalidOperation))?;

        Ok(())
    }

    pub fn len(&mut self) -> Result<u64> {
        let statement = &mut self.stmts.as_mut().unwrap().len;
        statement.reset()?;

        statement.next().or(Err(Error::InvalidOperation))?;
        let len: i64 = statement.read("len")?;

        Ok(len as u64)
    }
}
unsafe impl<'a> Send for IpInfoModule<'a> {}

struct Statements<'a> {
    pub insert: Statement<'a>,
    pub get_by_ip: Statement<'a>,
    pub len: Statement<'a>,
}

impl<'a> Statements<'a> {
    pub fn new(con: &'a Connection) -> Statements {
        con.execute(include_str!("init.sql")).unwrap();

        let insert: Statement<'a> = con.prepare(include_str!("insert.sql")).unwrap();
        let get_by_ip = con.prepare(include_str!("get_by_ip.sql")).unwrap();
        let len = con.prepare(include_str!("len.sql")).unwrap();

        return Self {
            insert,
            get_by_ip,
            len,
        };
    }
}
